/* =============================================
   StockIQ — app.js
   Real API calls → /api/stock, /api/predict
============================================= */

const API = window.location.origin;

Chart.defaults.color = '#94a3b8';
Chart.defaults.borderColor = 'rgba(255,255,255,0.06)';
Chart.defaults.font.family = "'DM Mono', monospace";
Chart.defaults.font.size = 11;

/* ── Navigation ── */
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    item.classList.add('active');
    const page = item.dataset.page;
    document.getElementById('page-' + page).classList.add('active');
    if (page === 'watchlist') loadWatchlist();
    if (page === 'sentiment') loadSentiment();
    if (page === 'alerts') renderAlerts();
  });
});

/* ── Clock ── */
function updateClock() {
  const now = new Date();
  const est = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  document.getElementById('marketClock').textContent =
    est.toTimeString().slice(0, 8) + ' EST';
}
setInterval(updateClock, 1000);
updateClock();

/* ── Helpers ── */
const fmt = (n, d = 2) => n == null ? '—' : Number(n).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
const fmtBig = n => {
  if (!n) return '—';
  if (n >= 1e12) return '$' + (n / 1e12).toFixed(2) + 'T';
  if (n >= 1e9)  return '$' + (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6)  return '$' + (n / 1e6).toFixed(2) + 'M';
  return '$' + n.toLocaleString();
};

/* ════════════════════════════════════════
   DASHBOARD
════════════════════════════════════════ */
let priceChart, volumeChart, rsiChart;
let currentSymbol = 'AAPL';
let currentRange = '1mo';

document.getElementById('loadStockBtn').addEventListener('click', () => {
  currentSymbol = document.getElementById('dashStock').value;
  loadDashboard(currentSymbol, currentRange);
});

document.querySelectorAll('.rtab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.rtab').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentRange = btn.dataset.range;
    loadDashboard(currentSymbol, currentRange);
  });
});

async function loadDashboard(symbol, range) {
  document.getElementById('chartStockLabel').textContent = symbol;
  document.getElementById('heroSymbol').textContent = symbol;

  try {
    const [quoteRes, histRes] = await Promise.all([
      fetch(`${API}/api/stock/quote?symbol=${symbol}`).then(r => r.json()),
      fetch(`${API}/api/stock/history?symbol=${symbol}&period=${range}`).then(r => r.json()),
    ]);

    // Hero card
    const q = quoteRes;
    document.getElementById('heroName').textContent = q.name || symbol;
    document.getElementById('heroPrice').textContent = '$' + fmt(q.price);
    const chgEl = document.getElementById('heroChange');
    const chgSign = q.change >= 0 ? '+' : '';
    chgEl.textContent = `${chgSign}$${fmt(q.change)} (${chgSign}${fmt(q.change_pct)}%)`;
    chgEl.className = 'hero-change ' + (q.change >= 0 ? 'up' : 'down');

    document.getElementById('hOpen').textContent = '$' + fmt(q.open);
    document.getElementById('hHigh').textContent = '$' + fmt(q.high);
    document.getElementById('hLow').textContent = '$' + fmt(q.low);
    document.getElementById('hVolume').textContent = fmtBig(q.volume).replace('$', '');
    document.getElementById('hMktCap').textContent = fmtBig(q.market_cap);
    document.getElementById('hPE').textContent = q.pe_ratio ? fmt(q.pe_ratio, 1) : '—';
    document.getElementById('h52H').textContent = '$' + fmt(q.week_52_high);
    document.getElementById('h52L').textContent = '$' + fmt(q.week_52_low);

    // Price chart
    const labels = histRes.dates;
    const prices = histRes.closes;
    const volumes = histRes.volumes;

    if (priceChart) priceChart.destroy();
    const ctx = document.getElementById('priceChart').getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 0, 260);
    grad.addColorStop(0, 'rgba(201,168,76,0.25)');
    grad.addColorStop(1, 'rgba(201,168,76,0.0)');

    priceChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: symbol,
          data: prices,
          borderColor: '#c9a84c',
          backgroundColor: grad,
          borderWidth: 2,
          pointRadius: 0,
          tension: 0.3,
          fill: true,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { maxTicksLimit: 8 } },
          y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { callback: v => '$' + v.toFixed(0) } }
        }
      }
    });

    // Volume chart
    if (volumeChart) volumeChart.destroy();
    volumeChart = new Chart(document.getElementById('volumeChart').getContext('2d'), {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          data: volumes,
          backgroundColor: prices.map((p, i) => i > 0 && p >= prices[i-1] ? 'rgba(34,197,94,0.5)' : 'rgba(239,68,68,0.5)'),
          borderRadius: 2,
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { display: false },
          y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { callback: v => fmtBig(v).replace('$','') } }
        }
      }
    });

    // RSI chart
    const rsi = computeRSI(prices, 14);
    if (rsiChart) rsiChart.destroy();
    rsiChart = new Chart(document.getElementById('rsiChart').getContext('2d'), {
      type: 'line',
      data: {
        labels: labels.slice(14),
        datasets: [
          { data: rsi, borderColor: '#c9a84c', borderWidth: 1.5, pointRadius: 0, tension: 0.3, fill: false },
          { data: new Array(rsi.length).fill(70), borderColor: 'rgba(239,68,68,0.4)', borderDash: [4,4], borderWidth: 1, pointRadius: 0 },
          { data: new Array(rsi.length).fill(30), borderColor: 'rgba(34,197,94,0.4)', borderDash: [4,4], borderWidth: 1, pointRadius: 0 },
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { display: false },
          y: { min: 0, max: 100, grid: { color: 'rgba(255,255,255,0.04)' } }
        }
      }
    });

  } catch (e) {
    console.error('Dashboard load error:', e);
  }
}

function computeRSI(prices, period = 14) {
  const rsi = [];
  for (let i = period; i < prices.length; i++) {
    let gains = 0, losses = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const diff = prices[j] - prices[j - 1];
      if (diff > 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period;
    const avgLoss = losses / period;
    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    rsi.push(parseFloat((100 - 100 / (1 + rs)).toFixed(2)));
  }
  return rsi;
}

/* ════════════════════════════════════════
   WATCHLIST
════════════════════════════════════════ */
const WATCH_SYMBOLS = ['AAPL', 'TSLA', 'MSFT', 'AMZN', 'GOOGL', 'NVDA', 'META'];
const COMPANY_NAMES = { AAPL: 'Apple Inc.', TSLA: 'Tesla Inc.', MSFT: 'Microsoft', AMZN: 'Amazon', GOOGL: 'Alphabet', NVDA: 'NVIDIA', META: 'Meta' };
let compareChart;

async function loadWatchlist() {
  const grid = document.getElementById('watchlistGrid');
  grid.innerHTML = WATCH_SYMBOLS.map(s => `
    <div class="watch-card" id="wc-${s}">
      <div class="wc-sym">${s}</div>
      <div class="wc-name">${COMPANY_NAMES[s]}</div>
      <div class="wc-price loading-shimmer">$000.00</div>
      <div class="wc-chg loading-shimmer">+0.00%</div>
      <canvas class="wc-mini-chart" id="mini-${s}"></canvas>
    </div>
  `).join('');

  // Load all quotes in parallel
  const results = await Promise.allSettled(
    WATCH_SYMBOLS.map(s => fetch(`${API}/api/stock/quote?symbol=${s}`).then(r => r.json()))
  );

  const compareLabels = [];
  const compareSeries = {};

  for (let i = 0; i < WATCH_SYMBOLS.length; i++) {
    const sym = WATCH_SYMBOLS[i];
    if (results[i].status !== 'fulfilled') continue;
    const q = results[i].value;

    const priceEl = document.querySelector(`#wc-${sym} .wc-price`);
    const chgEl   = document.querySelector(`#wc-${sym} .wc-chg`);
    priceEl.classList.remove('loading-shimmer');
    chgEl.classList.remove('loading-shimmer');
    priceEl.textContent = '$' + fmt(q.price);
    const sign = q.change_pct >= 0 ? '+' : '';
    chgEl.textContent = `${sign}${fmt(q.change_pct)}%`;
    chgEl.className = 'wc-chg ' + (q.change_pct >= 0 ? 'up' : 'down');
  }

  // Mini sparklines
  const histResults = await Promise.allSettled(
    WATCH_SYMBOLS.map(s => fetch(`${API}/api/stock/history?symbol=${s}&period=1mo`).then(r => r.json()))
  );

  const colors = ['#c9a84c','#22c55e','#60a5fa','#f97316','#a78bfa','#34d399','#fb7185'];

  for (let i = 0; i < WATCH_SYMBOLS.length; i++) {
    const sym = WATCH_SYMBOLS[i];
    if (histResults[i].status !== 'fulfilled') continue;
    const h = histResults[i].value;
    if (!h.closes || h.closes.length === 0) continue;

    const canvas = document.getElementById('mini-' + sym);
    const first = h.closes[0];
    const norm = h.closes.map(v => ((v - first) / first) * 100);
    const isUp = norm[norm.length - 1] >= 0;

    new Chart(canvas.getContext('2d'), {
      type: 'line',
      data: {
        labels: h.dates,
        datasets: [{ data: norm, borderColor: isUp ? '#22c55e' : '#ef4444', borderWidth: 1.5, pointRadius: 0, tension: 0.3, fill: false }]
      },
      options: { responsive: true, plugins: { legend: { display: false }, tooltip: { enabled: false } }, scales: { x: { display: false }, y: { display: false } } }
    });

    if (compareLabels.length === 0) compareLabels.push(...h.dates);
    compareSeries[sym] = { data: norm, color: colors[i] };
  }

  // Comparison chart
  if (compareChart) compareChart.destroy();
  compareChart = new Chart(document.getElementById('compareChart').getContext('2d'), {
    type: 'line',
    data: {
      labels: compareLabels,
      datasets: Object.entries(compareSeries).map(([sym, s]) => ({
        label: sym,
        data: s.data,
        borderColor: s.color,
        borderWidth: 1.5,
        pointRadius: 0,
        tension: 0.3,
        fill: false,
      }))
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, padding: 14 } } },
      scales: {
        x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { maxTicksLimit: 8 } },
        y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { callback: v => v.toFixed(1) + '%' } }
      }
    }
  });
}

document.getElementById('refreshWatchlist').addEventListener('click', loadWatchlist);

/* ════════════════════════════════════════
   QUICK STOCKS SIDEBAR
════════════════════════════════════════ */
async function loadQuickStocks() {
  const container = document.getElementById('quickStocks');
  const symbols = ['AAPL', 'TSLA', 'NVDA', 'MSFT'];
  container.innerHTML = symbols.map(s => `
    <div class="quick-stock-row" data-sym="${s}" onclick="switchToDashboard('${s}')">
      <span class="qs-sym">${s}</span>
      <div style="text-align:right">
        <div class="qs-price" id="qs-price-${s}">—</div>
        <div class="qs-chg" id="qs-chg-${s}">—</div>
      </div>
    </div>
  `).join('');

  const results = await Promise.allSettled(
    symbols.map(s => fetch(`${API}/api/stock/quote?symbol=${s}`).then(r => r.json()))
  );

  symbols.forEach((sym, i) => {
    if (results[i].status !== 'fulfilled') return;
    const q = results[i].value;
    document.getElementById('qs-price-' + sym).textContent = '$' + fmt(q.price);
    const chgEl = document.getElementById('qs-chg-' + sym);
    const sign = q.change_pct >= 0 ? '+' : '';
    chgEl.textContent = `${sign}${fmt(q.change_pct)}%`;
    chgEl.className = 'qs-chg ' + (q.change_pct >= 0 ? 'up' : 'down');
  });
}

function switchToDashboard(sym) {
  document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelector('[data-page="dashboard"]').classList.add('active');
  document.getElementById('page-dashboard').classList.add('active');
  document.getElementById('dashStock').value = sym;
  currentSymbol = sym;
  loadDashboard(sym, currentRange);
}

/* ════════════════════════════════════════
   PREDICTIONS
════════════════════════════════════════ */
let forecastChart, featureChart;

document.getElementById('runPredictBtn').addEventListener('click', async () => {
  const symbol = document.getElementById('predictStock').value;
  try {
    const res = await fetch(`${API}/api/predict?symbol=${symbol}`).then(r => r.json());
    document.getElementById('pmSymbol').textContent = symbol;
    document.getElementById('pmCurrent').textContent = '$' + fmt(res.current_price);
    document.getElementById('pmForecast').textContent = '$' + fmt(res.predicted_price);
    const move = res.predicted_price - res.current_price;
    const movePct = (move / res.current_price * 100);
    const moveEl = document.getElementById('pmMove');
    moveEl.textContent = (move >= 0 ? '+' : '') + '$' + fmt(move) + ' (' + (movePct >= 0 ? '+' : '') + fmt(movePct) + '%)';
    moveEl.style.color = move >= 0 ? 'var(--green)' : 'var(--red)';
    document.getElementById('pmConf').textContent = fmt(res.confidence * 100, 1) + '%';

    const sig = res.signal;
    const sigEl = document.getElementById('pmSignal');
    sigEl.innerHTML = `<span class="chip ${sig.toLowerCase()}">${sig}</span>`;

    document.getElementById('r2Score').textContent = fmt(res.metrics.r2, 3);
    document.getElementById('maeScore').textContent = '$' + fmt(res.metrics.mae);
    document.getElementById('dirAcc').textContent = fmt(res.metrics.direction_accuracy * 100, 1) + '%';

    // Forecast chart
    if (forecastChart) forecastChart.destroy();
    const fc = document.getElementById('forecastChart').getContext('2d');
    const days = res.forecast_days.map((_, i) => `Day +${i + 1}`);
    forecastChart = new Chart(fc, {
      type: 'line',
      data: {
        labels: [...res.history_labels.slice(-30), ...days],
        datasets: [
          {
            label: 'Historical',
            data: [...res.history_prices.slice(-30), ...new Array(7).fill(null)],
            borderColor: '#94a3b8', borderWidth: 1.5, pointRadius: 0, tension: 0.3, fill: false,
          },
          {
            label: 'Forecast',
            data: [...new Array(30).fill(null), res.current_price, ...res.forecast_days],
            borderColor: '#c9a84c', borderWidth: 2, borderDash: [5, 5], pointRadius: 3, pointBackgroundColor: '#c9a84c', tension: 0.3, fill: false,
          },
          {
            label: 'Upper Band',
            data: [...new Array(30).fill(null), res.current_price, ...res.upper_band],
            borderColor: 'rgba(201,168,76,0.25)', borderWidth: 1, pointRadius: 0, tension: 0.3, fill: false,
          },
          {
            label: 'Lower Band',
            data: [...new Array(30).fill(null), res.current_price, ...res.lower_band],
            borderColor: 'rgba(201,168,76,0.25)', backgroundColor: 'rgba(201,168,76,0.06)', borderWidth: 1, pointRadius: 0, tension: 0.3, fill: '-1',
          },
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { maxTicksLimit: 10 } },
          y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { callback: v => '$' + v.toFixed(0) } }
        }
      }
    });

    // Feature importance chart
    if (featureChart) featureChart.destroy();
    featureChart = new Chart(document.getElementById('featureChart').getContext('2d'), {
      type: 'bar',
      data: {
        labels: res.feature_importance.map(f => f.name),
        datasets: [{ data: res.feature_importance.map(f => f.value), backgroundColor: '#c9a84c99', borderRadius: 4, borderSkipped: false }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { x: { grid: { color: 'rgba(255,255,255,0.04)' } }, y: { grid: { color: 'rgba(255,255,255,0.04)' } } }
      }
    });

  } catch (e) {
    console.error('Prediction error:', e);
  }
});

/* ════════════════════════════════════════
   SENTIMENT
════════════════════════════════════════ */
let sentimentGaugeChart;

document.getElementById('sentimentStock').addEventListener('change', loadSentiment);

async function loadSentiment() {
  const symbol = document.getElementById('sentimentStock').value;
  try {
    const res = await fetch(`${API}/api/sentiment?symbol=${symbol}`).then(r => r.json());
    const s = res.scores;

    document.getElementById('sentScore').textContent = fmt(res.overall_score * 100, 0) + '%';
    document.getElementById('sentLabel').textContent = res.label.toUpperCase();
    document.getElementById('sentPos').style.width = (s.positive * 100) + '%';
    document.getElementById('sentNeu').style.width = (s.neutral * 100) + '%';
    document.getElementById('sentNeg').style.width = (s.negative * 100) + '%';
    document.getElementById('sentPosVal').textContent = fmt(s.positive * 100, 0) + '%';
    document.getElementById('sentNeuVal').textContent = fmt(s.neutral * 100, 0) + '%';
    document.getElementById('sentNegVal').textContent = fmt(s.negative * 100, 0) + '%';

    // News list
    const newsList = document.getElementById('newsList');
    newsList.innerHTML = res.headlines.map(h => `
      <div class="news-item">
        <div class="news-sent ${h.sentiment}"></div>
        <div class="news-body">
          <div class="news-headline">${h.title}</div>
          <div class="news-meta">${h.source} · ${h.time}</div>
        </div>
      </div>
    `).join('');

  } catch (e) { console.error('Sentiment error:', e); }
}

/* ════════════════════════════════════════
   MARKET INDICES
════════════════════════════════════════ */
async function loadIndices() {
  try {
    const res = await fetch(`${API}/api/indices`).then(r => r.json());
    const set = (id, val, chg) => {
      const sign = chg >= 0 ? '+' : '';
      document.getElementById(id).textContent = fmt(val, 2);
      const chgEl = document.getElementById(id + 'chg');
      chgEl.textContent = `${sign}${fmt(chg, 2)}%`;
      chgEl.className = 't-chg ' + (chg >= 0 ? 'up' : 'down');
    };
    set('sp500',  res.sp500.price,  res.sp500.change_pct);
    set('nasdaq', res.nasdaq.price, res.nasdaq.change_pct);
    set('dow',    res.dow.price,    res.dow.change_pct);
  } catch (e) {}
}

/* ════════════════════════════════════════
   ALERTS
════════════════════════════════════════ */
let userAlerts = [
  { id: 1, symbol: 'AAPL', type: 'above', value: 210, triggered: false, created: '10 min ago' },
  { id: 2, symbol: 'TSLA', type: 'below', value: 170, triggered: false, created: '1 hr ago' },
];

function renderAlerts() {
  const list = document.getElementById('alertsList');
  if (userAlerts.length === 0) {
    list.innerHTML = '<p style="color:var(--text-3);text-align:center;padding:32px;font-family:DM Mono,monospace;">No alerts configured.</p>';
    return;
  }
  list.innerHTML = userAlerts.map(a => `
    <div class="alert-row ${a.triggered ? 'triggered' : ''}">
      <span class="ar-sym">${a.symbol}</span>
      <span class="ar-desc">
        Notify when price goes <strong>${a.type}</strong>
        <span style="color:var(--gold);font-family:DM Mono,monospace"> $${fmt(a.value)}</span>
        ${a.triggered ? ' <span style="color:var(--green)">✓ Triggered</span>' : ''}
      </span>
      <span class="ar-time">${a.created}</span>
      <button class="ar-del" onclick="deleteAlert(${a.id})">✕</button>
    </div>
  `).join('');
  document.getElementById('alertNavBadge').textContent = userAlerts.filter(a => !a.triggered).length;
}

function deleteAlert(id) {
  userAlerts = userAlerts.filter(a => a.id !== id);
  renderAlerts();
}

document.getElementById('createAlertBtn').addEventListener('click', () => {
  const symbol = document.getElementById('alertStock').value;
  const type   = document.getElementById('alertType').value;
  const value  = parseFloat(document.getElementById('alertValue').value);
  if (!value || isNaN(value)) return;
  userAlerts.push({ id: Date.now(), symbol, type, value, triggered: false, created: 'Just now' });
  document.getElementById('alertValue').value = '';
  renderAlerts();
});

document.getElementById('clearAlertsBtn').addEventListener('click', () => {
  userAlerts = [];
  renderAlerts();
});

/* ════════════════════════════════════════
   INIT
════════════════════════════════════════ */
loadDashboard('AAPL', '1mo');
loadQuickStocks();
loadIndices();
setInterval(loadIndices, 60000);
setInterval(loadQuickStocks, 60000);
