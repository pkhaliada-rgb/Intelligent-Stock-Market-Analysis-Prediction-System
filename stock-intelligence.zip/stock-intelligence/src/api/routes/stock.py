"""Stock data endpoints using yfinance for real market data."""
from fastapi import APIRouter, HTTPException, Query
import yfinance as yf
from datetime import datetime

router = APIRouter()

VALID_SYMBOLS = {
    "AAPL", "TSLA", "MSFT", "AMZN", "GOOGL",
    "NVDA", "META", "NFLX", "AMD", "INTC",
}

COMPANY_NAMES = {
    "AAPL":  "Apple Inc.",
    "TSLA":  "Tesla Inc.",
    "MSFT":  "Microsoft Corporation",
    "AMZN":  "Amazon.com Inc.",
    "GOOGL": "Alphabet Inc.",
    "NVDA":  "NVIDIA Corporation",
    "META":  "Meta Platforms Inc.",
    "NFLX":  "Netflix Inc.",
    "AMD":   "Advanced Micro Devices",
    "INTC":  "Intel Corporation",
}


def _safe(val):
    """Convert numpy types to Python native."""
    try:
        if val is None:
            return None
        v = float(val)
        return round(v, 4) if v == v else None  # NaN check
    except Exception:
        return None


@router.get("/quote")
async def get_quote(symbol: str = Query(..., description="Stock ticker symbol")):
    symbol = symbol.upper()
    try:
        ticker = yf.Ticker(symbol)
        info = ticker.info
        hist = ticker.history(period="2d")

        if hist.empty:
            raise HTTPException(404, f"No data for {symbol}")

        current = _safe(hist["Close"].iloc[-1])
        prev    = _safe(hist["Close"].iloc[-2]) if len(hist) >= 2 else current
        change  = round(current - prev, 4) if current and prev else 0
        change_pct = round((change / prev) * 100, 4) if prev else 0

        return {
            "symbol":       symbol,
            "name":         COMPANY_NAMES.get(symbol, info.get("longName", symbol)),
            "price":        current,
            "open":         _safe(hist["Open"].iloc[-1]),
            "high":         _safe(hist["High"].iloc[-1]),
            "low":          _safe(hist["Low"].iloc[-1]),
            "volume":       int(hist["Volume"].iloc[-1]) if not hist.empty else None,
            "change":       change,
            "change_pct":   change_pct,
            "market_cap":   _safe(info.get("marketCap")),
            "pe_ratio":     _safe(info.get("trailingPE")),
            "week_52_high": _safe(info.get("fiftyTwoWeekHigh")),
            "week_52_low":  _safe(info.get("fiftyTwoWeekLow")),
            "timestamp":    datetime.utcnow().isoformat(),
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Failed to fetch {symbol}: {str(e)}")


@router.get("/history")
async def get_history(
    symbol: str = Query(...),
    period: str = Query("1mo", description="1mo | 3mo | 6mo | 1y"),
):
    symbol = symbol.upper()
    valid_periods = {"1mo", "3mo", "6mo", "1y"}
    if period not in valid_periods:
        period = "1mo"
    try:
        ticker = yf.Ticker(symbol)
        hist = ticker.history(period=period)

        if hist.empty:
            raise HTTPException(404, f"No history for {symbol}")

        dates   = [d.strftime("%b %d") for d in hist.index]
        closes  = [_safe(v) for v in hist["Close"].values]
        opens   = [_safe(v) for v in hist["Open"].values]
        highs   = [_safe(v) for v in hist["High"].values]
        lows    = [_safe(v) for v in hist["Low"].values]
        volumes = [int(v) for v in hist["Volume"].values]

        return {
            "symbol":  symbol,
            "period":  period,
            "dates":   dates,
            "closes":  closes,
            "opens":   opens,
            "highs":   highs,
            "lows":    lows,
            "volumes": volumes,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Failed to fetch history: {str(e)}")
