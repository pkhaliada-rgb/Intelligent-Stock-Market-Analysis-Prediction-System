"""Market indices endpoint — S&P 500, NASDAQ, DOW Jones."""
from fastapi import APIRouter, HTTPException
import yfinance as yf
from datetime import datetime

router = APIRouter()


def _safe(val):
    try:
        v = float(val)
        return round(v, 2) if v == v else None
    except Exception:
        return None


def _get_index(ticker_sym: str) -> dict:
    ticker = yf.Ticker(ticker_sym)
    hist = ticker.history(period="2d")
    if hist.empty:
        return {"price": None, "change": None, "change_pct": None}
    current = _safe(hist["Close"].iloc[-1])
    prev    = _safe(hist["Close"].iloc[-2]) if len(hist) >= 2 else current
    change  = round(current - prev, 2) if current and prev else 0
    change_pct = round((change / prev) * 100, 3) if prev else 0
    return {"price": current, "change": change, "change_pct": change_pct}


@router.get("")
async def get_indices():
    try:
        return {
            "sp500":  _get_index("^GSPC"),
            "nasdaq": _get_index("^IXIC"),
            "dow":    _get_index("^DJI"),
            "timestamp": datetime.utcnow().isoformat(),
        }
    except Exception as e:
        raise HTTPException(500, f"Failed to fetch indices: {str(e)}")
