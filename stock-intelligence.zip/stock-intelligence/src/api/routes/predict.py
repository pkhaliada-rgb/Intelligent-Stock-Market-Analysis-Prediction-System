"""
ML Price Prediction endpoint.
Uses real yfinance historical data + Linear Regression + feature engineering.
"""
from fastapi import APIRouter, HTTPException, Query
import yfinance as yf
import numpy as np
from datetime import datetime

router = APIRouter()


def _safe(val):
    try:
        v = float(val)
        return round(v, 4) if v == v else None
    except Exception:
        return None


def _compute_features(closes: list[float]) -> np.ndarray:
    """Build feature matrix from price series."""
    closes = np.array(closes)
    rows = []
    for i in range(20, len(closes)):
        price  = closes[i - 1]
        ma5    = closes[i-5:i].mean()
        ma10   = closes[i-10:i].mean()
        ma20   = closes[i-20:i].mean()
        std5   = closes[i-5:i].std()
        std20  = closes[i-20:i].std()
        ret1   = (closes[i-1] - closes[i-2]) / closes[i-2]
        ret5   = (closes[i-1] - closes[i-6]) / closes[i-6]
        ret10  = (closes[i-1] - closes[i-11]) / closes[i-11]
        pma5   = price / ma5 - 1
        pma20  = price / ma20 - 1
        # RSI simplified
        diffs = np.diff(closes[i-14:i])
        gains = diffs[diffs > 0].sum()
        losses = -diffs[diffs < 0].sum()
        rsi = 50 if losses == 0 else 100 - 100 / (1 + gains / losses)
        rows.append([price, ma5, ma10, ma20, std5, std20, ret1, ret5, ret10, pma5, pma20, rsi / 100])
    return np.array(rows)


def _linear_regression(X: np.ndarray, y: np.ndarray):
    """Pure numpy least-squares linear regression."""
    Xb = np.hstack([np.ones((X.shape[0], 1)), X])
    try:
        coeffs, _, _, _ = np.linalg.lstsq(Xb, y, rcond=None)
    except Exception:
        coeffs = np.zeros(Xb.shape[1])
    return coeffs


def _predict(coeffs, x_row):
    xb = np.concatenate([[1.0], x_row])
    return float(np.dot(coeffs, xb))


def _r2(y_true, y_pred):
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - y_true.mean()) ** 2)
    return float(1 - ss_res / (ss_tot + 1e-9))


@router.get("")
async def predict_price(symbol: str = Query(...)):
    symbol = symbol.upper()
    try:
        ticker = yf.Ticker(symbol)
        hist = ticker.history(period="6mo")

        if hist.empty or len(hist) < 60:
            raise HTTPException(400, f"Not enough data for {symbol}")

        closes = [_safe(v) for v in hist["Close"].values]
        dates  = [d.strftime("%b %d") for d in hist.index]

        X = _compute_features(closes)
        if len(X) < 10:
            raise HTTPException(400, "Insufficient data for prediction")

        y = np.array(closes[20:])  # next-day prices (target = close[i])

        # Train/test split (80/20)
        split = int(len(X) * 0.8)
        X_train, X_test = X[:split], X[split:]
        y_train, y_test = y[:split], y[split:]

        coeffs = _linear_regression(X_train, y_train)

        # Metrics
        y_pred_test = np.array([_predict(coeffs, row) for row in X_test])
        mae = float(np.mean(np.abs(y_test - y_pred_test)))
        r2  = _r2(y_test, y_pred_test)
        dir_acc = float(np.mean(
            np.sign(np.diff(y_test)) == np.sign(np.diff(y_pred_test))
        ))

        # Predict next 7 days using last row + rolling
        current_price = closes[-1]
        forecast = []
        rolling = list(closes[-30:])
        for _ in range(7):
            feats = _compute_features(rolling)
            if len(feats) == 0:
                break
            pred = _predict(coeffs, feats[-1])
            pred = max(pred, current_price * 0.7)  # sanity clamp
            forecast.append(round(pred, 2))
            rolling.append(pred)

        std_dev = float(np.std(closes[-30:]))
        upper = [round(f + std_dev * 1.65, 2) for f in forecast]
        lower = [round(max(f - std_dev * 1.65, 0), 2) for f in forecast]

        predicted_next = forecast[0] if forecast else current_price
        move_pct = (predicted_next - current_price) / current_price * 100
        signal = "BUY" if move_pct > 1.5 else ("SELL" if move_pct < -1.5 else "HOLD")

        feature_names = ["Price", "MA5", "MA10", "MA20", "Std5", "Std20", "Ret1d", "Ret5d", "Ret10d", "P/MA5", "P/MA20", "RSI"]
        importances = [abs(float(c)) for c in coeffs[1:]]
        total = sum(importances) or 1
        feature_importance = sorted(
            [{"name": n, "value": round(v / total * 100, 1)} for n, v in zip(feature_names, importances)],
            key=lambda x: -x["value"]
        )[:8]

        return {
            "symbol":           symbol,
            "current_price":    round(current_price, 2),
            "predicted_price":  predicted_next,
            "forecast_days":    forecast,
            "upper_band":       upper,
            "lower_band":       lower,
            "signal":           signal,
            "confidence":       round(min(max(r2, 0), 1), 3),
            "history_labels":   dates,
            "history_prices":   closes,
            "feature_importance": feature_importance,
            "metrics": {
                "r2":                 round(r2, 4),
                "mae":                round(mae, 2),
                "direction_accuracy": round(dir_acc, 4),
            },
            "timestamp": datetime.utcnow().isoformat(),
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Prediction failed: {str(e)}")
