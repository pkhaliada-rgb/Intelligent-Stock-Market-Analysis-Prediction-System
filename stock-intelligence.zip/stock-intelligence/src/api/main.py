"""
StockIQ — FastAPI Backend
Serves dashboard + real-time stock data via yfinance
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pathlib import Path

from .routes import stock, predict, sentiment, indices

BASE_DIR = Path(__file__).resolve().parent.parent.parent  # project root

app = FastAPI(
    title="StockIQ API",
    description="Real-time stock market intelligence with ML predictions",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
STATIC_DIR = BASE_DIR / "dashboard" / "static"
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# API routes
app.include_router(stock.router,     prefix="/api/stock",     tags=["Stock Data"])
app.include_router(predict.router,   prefix="/api/predict",   tags=["Predictions"])
app.include_router(sentiment.router, prefix="/api/sentiment", tags=["Sentiment"])
app.include_router(indices.router,   prefix="/api/indices",   tags=["Indices"])

@app.get("/", response_class=FileResponse)
async def dashboard():
    index = BASE_DIR / "dashboard" / "templates" / "index.html"
    return FileResponse(str(index))

@app.get("/api")
def api_root():
    return {"service": "StockIQ", "version": "1.0.0", "docs": "/api/docs"}
